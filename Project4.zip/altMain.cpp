#include "hash.h"

using namespace std; 

int main(){
    string word; 
    int wordCount = 0;
    int searches = 0;
    hashTable H1;
    // Set up hash table with internal nodes
    H1.SetUp();
    // Cin words from text document
    while((cin >> word)){
        wordCount = wordCount + 1;
        extNode *newExt = new extNode(word);
	// Insert node into hash table
	H1.insertNode(newExt, searches);
    }
    cout << "Searching comparisons in hash table: " << searches << endl;
    H1.printPositions();
    // Print sorted data from hash tables
    int comparisonsAlpha = 0;
    int comparisonsNumerical = 0;
    H1.printAlphaStat(wordCount, comparisonsAlpha);
    cout << "Sorting comparisons for alphabetical sort: " << comparisonsAlpha;
    cout << endl << endl;
    H1.printNumericalStat(wordCount, comparisonsNumerical);
    cout << "Sorting comarisons for numerical sort: ";
    cout << comparisonsNumerical << endl;

    cout << "Sorting comparions in total: ";
    cout << comparisonsAlpha + comparisonsNumerical <<endl;
}
