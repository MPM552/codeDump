Class: CS216-002
Author: Matthew Mitchell
Project 1 Readme

Purpose of files:

Gradebook.cpp - Defines the gradebook class. Functions include appending new
Final Grade objects, returning gradebook size, finding max, min, and average,
incrementing score, and printing.
 
Gradebook.h - Contains the function declarations to be used in Gradebook.cpp.

FinalGrade.cpp - Defines the FinalGrade class. Functions include passing a
FinalGrade object, changing a score, returning a score, returning a letter
grade, and printing a a score with letter grade.

FinalGrade.h - Contains the funcion declarations to be used in finalGrade.cpp.

PA1.cpp - Contains a main that implements functions from Gradebook.cpp and 
FinalGrade.cpp. Allows a user to input test values and increment them based on
an expected average score.

How to compile source code:
type: g++ FinalGrade.cpp Gradebook.cpp PA1.cpp -o CS216PA1
then: ./CS216PA1
 
