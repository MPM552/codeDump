 /* 
 * File:   Gradebook.cpp
 * Course: CS216
 * Project: Lab 5 (as second part of Project 1)
 * Purpose: provide the implementation of the member functions of Gradebook class
 *
 * Author: Matthew Mitchell
 *
 */
#include <iostream>
#include "Gradebook.h"

// default constructor
Gradebook::Gradebook()
{
}

// return the size of the current vector: scores, 
// which represents current gradebook
int Gradebook::getSize() const
{
	return scores.size();  
}
    
// insert a FinalGrade object, newFG, 
// into the end of the current gradebook
void Gradebook::insert(FinalGrade newFG)
{
	scores.push_back(newFG);
}

// return a FinalGrade object, 
// which holds the maximum score in the current gradebook
FinalGrade Gradebook::getMax() const
{
	// set max equal to first score
	FinalGrade max = scores[0];
	// search for max score
	for (int i=0; i < getSize(); i++){
		if (max.getScore() < scores[i].getScore())
			max = scores[i];
	}
	// return "max" object
	return max;
}

// return a FinalGrade object,
// which holds the minimum score in the current gradebook
FinalGrade Gradebook::getMin() const
{	// set min equal to first score
	FinalGrade min = scores[0];
	// search for min score
	for (int i=0; i < getSize(); i++){
		if (min.getScore() > scores[i].getScore())
			min = scores[i];
	}
	// return "min" object
	return min;

}
    
// return the average score among all scores in the current gradebook
double Gradebook::getAverage() const
{
	// set total as 0, add scores, and return average
	double total = 0;
	for (int i=0; i < getSize(); i++)
		total = total + scores[i].getScore();
	double average = total / getSize();
	return average;
}

// For each FinalGrade object in the current gradebook, 
// its score will be increased by the given value 
// If the score reaches MAX_SCORE, it does not go beyond
void Gradebook::incrementScore(double value)
{
	// increment scores unless the score is greater 
	// than MAX_SCORE. In that case, set score 
	// equal to MAX_SCORE.
	for (int i=0; i < getSize(); i++){
		double maxCheck = scores[i].getScore() + value;
		if (maxCheck > MAX_SCORE)
			scores[i].setScore(MAX_SCORE);
		else
			scores[i].setScore(maxCheck);
	}
}
    
// print the FinalGrade objects in the current gradebook
void Gradebook::print() const
{	
	// print scores and letter grades
	for (int i=0; i < getSize(); i++)
		scores[i].print();
}

