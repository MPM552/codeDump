/*
 * Course: CS216-002
 * Project: Project 1
 * Purpose: Allow a user to input test values and increment those
 * test values based on an expected average score. Essentially,
 * allow a used to implement a grade curve.
 * Author: Matthew Mitchell
 * Date: 9/29/19
 */

#include <iostream>
#include <iomanip>
#include <string>
#include <cmath>
#include "Gradebook.h"

using namespace std;

int main()
{
	Gradebook CS216Gradebook_original;
	double input_score;

	while (true)
	{
		cout << "Please enter a score for CS216 (type 'Q' or 'q' to quit)" << endl;
		cin >> input_score;
		cin.ignore(256, '\n');

		// check if inPut is invalid
		if (cin.fail())
		{
			string check_input;
			cin.clear();
			cin >> check_input;
		cin.ignore(256, '\n');
			if (check_input == "Q" || check_input == "q")
				break;
			else {
				cout << "Invalid input, please try agian..." << endl;
				continue;
			}
		}

		// Check for correct rangle
		if (input_score < 0 || input_score > 100)
		{
			cout << "The score is not in the correct range, please try again..." << endl;
		}
		else
		{
			FinalGrade inputFG(input_score);
			CS216Gradebook_original.insert(inputFG);
		}
	}
	// Check if gradebook is empty
	// If empty, report it then quit 
	if (CS216Gradebook_original.getSize() == 0)
	{
		cout << "The gradebook for CS216 is empty!" << endl;
		cout << "Thanks for using the Grade Curve Calculator." << endl;
		return 1;
	}

	cout << endl;
	double average = CS216Gradebook_original.getAverage();
	double expAvg = 0;
	cout << fixed << setprecision(2);
	while  (true)
	{
		cout << "The original average score is: " << average << endl;
		cout << "Please enter your expected average score to curve (type 'Q' or 'q' to quit): " << endl;;

		cin >> expAvg;
		cin.ignore(256, '\n');

		// Check if input is invalid
		if (cin.fail())
		{
			string check_input;
			cin.clear();
			cin >> check_input;
			cin.ignore(256, '\n');
			if (check_input == "Q" || check_input == "q")
				break;
			else {
				cout << "Invalid input, please try again..." << endl;
				continue;
			}
		}
	
		// Check range
		if (expAvg < average || expAvg > MAX_SCORE)
		{
			cout << "The score is not in the correct range, please try again..." << endl <<endl; 
		}
		else
		{
			Gradebook CS216Gradebook_revised = CS216Gradebook_original;
			double diff = expAvg - CS216Gradebook_original.getAverage();
			const double EPSILON = 1.0e-2;
	        	if (abs(diff) < EPSILON)
            			cout << "The scores are perfect, no need for the grading curve!" << endl << endl;
      			else  // valid expected average, adjust scores accordingly
           		{
				// Original print
				CS216Gradebook_revised.incrementScore(diff);
				cout << "The curved original for CS216: " << endl;
                		CS216Gradebook_original.print();
                		cout << "The number of scores is:\t" << CS216Gradebook_original.getSize() << endl;
                		cout << "The maximum score is:\t";
                		CS216Gradebook_original.getMax().print();
                		cout << "The minimum score is:\t";
               			CS216Gradebook_original.getMin().print();
                		cout << "The actual average score is:\t" << CS216Gradebook_original.getAverage() << endl <<endl;
           			// Curved print
				cout << "The curved gradebook for CS216: " << endl;
                		CS216Gradebook_revised.print();
                		cout << "The number of scores is:\t" << CS216Gradebook_revised.getSize() << endl;
                		cout << "The maximum score is:\t";
                		CS216Gradebook_revised.getMax().print();
                		cout << "The minimum score is:\t";
                		CS216Gradebook_revised.getMin().print();
                		cout << "The actual average score is:\t" << CS216Gradebook_revised.getAverage() << endl <<endl;
       	   		}
		}

	}	
cout << "Thank you for using the Grade Curve Calculator." << endl;	
return 0;
}	
	
